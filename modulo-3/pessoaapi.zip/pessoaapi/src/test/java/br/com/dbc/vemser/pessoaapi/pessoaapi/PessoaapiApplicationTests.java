package br.com.dbc.vemser.pessoaapi.pessoaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoaapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
