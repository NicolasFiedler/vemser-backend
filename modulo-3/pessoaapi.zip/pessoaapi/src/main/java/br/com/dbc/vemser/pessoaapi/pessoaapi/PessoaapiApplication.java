package br.com.dbc.vemser.pessoaapi.pessoaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PessoaapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PessoaapiApplication.class, args);
	}

}
